#include <cs50.h>
#include <stdio.h>

int main(void) {
    int height = 0;
    do {
        height = get_int("Height: ");
    } while (height < 1 || height > 8);

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < height; j++) {
            if (j >= height - (i + 1)) {
                printf("#");
            } else {
                printf(" ");
            }
        }
        printf(" ");
        printf(" ");
        for (int j = 0; j < i + 1; j++) {
            printf("#");
        }
         printf("\n");
    }
}
